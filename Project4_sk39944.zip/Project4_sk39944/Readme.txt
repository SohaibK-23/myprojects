Linux commands needed for compiling and running the program

To compile: javac -cp lib/jackson-annotations-2.10.0.pr3.jar:lib/jackson-core-2.10.0.pr3.jar:lib/jackson-databind-2.9.0.jar:lib/jackson-databind-2.9.0-javadoc.jar:lib/jackson-databind-2.9.0-sources.jar:lib/jackson-databind-2.10.0.pr3.jar:lib/okhttp-3.9.0.jar:lib/okio-1.13.0.jar src/assignment4/*.java -d bin

To run: java -cp bin:lib/jackson-annotations-2.10.0.pr3.jar:lib/jackson-core-2.10.0.pr3.jar:lib/jackson-databind-2.9.0.jar:lib/jackson-databind-2.9.0-javadoc.jar:lib/jackson-databind-2.9.0-sources.jar:lib/jackson-databind-2.10.0.pr3.jar:lib/okhttp-3.9.0.jar:lib/okio-1.13.0.jar assignment4/Main